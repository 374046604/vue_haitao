<template>
  <div class="home clearfix">
    <div class="left">
      <img class="img" src="./u139.jpg" alt="">
    </div>
    <div class="right"></div>
  </div>
</template>

<script>
export default {
  name: 'home',
  data() {
    return {
      theImgList:['./u101.jpg','./u99.jpg','./u97.jpg']
    }
  },
  components: {
  },
  mounted() {
    var _this = this;
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss">
.home {
  background: red;
  .left {
    float: left;
    width: 40%;
    text-align: center;
    .img {
      height: 450px;
      width: 250px;
    }
  }
  .right {

  }
}
</style>
